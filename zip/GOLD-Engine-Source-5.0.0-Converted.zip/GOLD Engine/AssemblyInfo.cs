
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly


// TODO: Review the values of the assembly attributes


[assembly: AssemblyTitle("GOLD Parser Engine")]
[assembly: AssemblyDescription("This componant is shareware. You are free to copy and use this application, but I would appreciate it if you would SHARE your feedback with me.")]
[assembly: AssemblyCompany("Devin D. Cook (www.DevinCook.com/GOLDParser)")]
[assembly: AssemblyProduct("GOLD Parser Engine")]
[assembly: AssemblyCopyright("Free!")]
[assembly: AssemblyTrademark("")]

[assembly: AssemblyCulture("")]
// Version information for an assembly consists of the following four values:

//	Major version
//	Minor Version
//	Revision
//	Build Number

// You can specify all the values or you can default the Revision and Build Numbers
// by using the '*' as shown below



[assembly: AssemblyVersion("5.0.*")]


[assembly: ComVisibleAttribute(true)]

//=======================================================
//Service provided by Telerik (www.telerik.com)
//Conversion powered by NRefactory.
//Twitter: @telerik, @toddanglin
//Facebook: facebook.com/telerik
//=======================================================
